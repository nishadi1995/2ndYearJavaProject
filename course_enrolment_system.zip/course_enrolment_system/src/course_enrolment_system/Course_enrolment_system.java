
package course_enrolment_system;


public class Course_enrolment_system {

    
    public static void main(String[] args) {
        MainFrame mf = new MainFrame();
        mf.setVisible(true);                    //to show the main window
    }
    
}
