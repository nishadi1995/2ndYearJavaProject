
package course_enrolment_system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

//this class is next to the database layer(backend)

public class DBOperations {
    
    String url = "jdbc:mysql://localhost:3306/course_enrolment_system";  //Since the DB is installed in the same computer IP adress is localhost
    String username = "root";                                            //mysql service is running in port 3306.This url is to find the location of the DB 
    String password = "";
    Connection con = null;
    PreparedStatement pst,pst1 = null;
    ResultSet rs= null;
 
   public void connection(){
        try{
             con = DriverManager.getConnection(url, username , password);   //get the connection.This throws a SQLException
        }catch(Exception e){
            System.out.println(e);
        }
    
    }
    
    void checkvalidation(String logusername, String logpassword){
      try{
         connection();
         String query1 = "SELECT * FROM login WHERE username= ?";        //sql query to run
         
         pst=con.prepareStatement(query1);                              //A SQL statement with or without IN parameters can be pre-compiled and stored in a PreparedStatement object.This object can then be used to efficiently execute this statement multiple times.
         pst.setString(1,logusername);                                 //sets the parameter to a string.Driver then converts it to a SQL VARCHAR when it sends to the DB 
         rs=pst.executeQuery();                                        // execute the sql query and returns the object containing the data produced by the query
         rs.next ();                                                   //moves the cursor one row forword from the current position
         
         if(logpassword.equals(rs.getString(2))){                      //retrives the value in 2nd colomn in resultset object
             SecondWindow sw = new SecondWindow();
             sw.setVisible(true);
         }else{
             JOptionPane.showMessageDialog(null, "Password is incorrect");
         }
         
      }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error! Entered username doesn't exsist");
            System.out.println(e);
      }
    }
    
    public static java.sql.Date getCurrentDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
    
    void addUndergraduate(UndergratDetails ud){
     try{
        connection();
        String query2 = "INSERT INTO undergraduate VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        pst=con.prepareStatement(query2);
       
        //pst1=con.prepareStatement(query7);
        
        pst.setInt(1, ud.getStd_id());                         //add values to sql query
        pst.setString(2, ud.getFirstname());                   //add values to sql query
        pst.setString(3, ud.getMidname());                     //add values to sql query
        pst.setString(4, ud.getLastname());                    //add values to sql query
        pst.setString(5,ud.getNic());                          //add values to sql query
        pst.setDate(6, ud.getDob());
        pst.setInt(7,0);
        pst.setString(8,ud.getAddress());
        pst.setInt(9, ud.getConnum());
        pst.setString(10,Character.toString(ud.getGender()));
        pst.setString(11, ud.getIntake());
        pst.setDate(12,getCurrentDate());
        pst.setString(13,ud.getAlresults());
        pst.setInt(14,ud.getDrank()); 
        pst.setInt(15,ud.getIrank());
        pst.setDouble(16,ud.getZscore());
        
        pst.executeUpdate();                               //execute the sql query and add values to db table
        //String query7="UPDATE undergraduate SET age = TIMESTAMPDIFF(YEAR,,CURDATE()";
        //pst1.setDate(1,);
        String query4="SELECT std_id FROM undergraduate ORDER BY std_id DESC LIMIT 1";
        pst1=con.prepareStatement(query4);
        rs=pst1.executeQuery();
        rs.next (); 
        JOptionPane.showMessageDialog(null, "Inserted successfully! Student ID is "+rs.getString(1));
     }
     catch(Exception e){
        System.out.println(e);
     }
    }
    
    
    void addPostgraduate(PostgratDetails pd){
        
     try{
       con = DriverManager.getConnection(url, username , password); 
       String query5= "INSERT INTO postgraduate VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
       pst=con.prepareStatement(query5);
       
       pst.setInt(1, pd.getStd_id());                         
       pst.setString(2, pd.getFirstname());                   
       pst.setString(3, pd.getMidname());                     
       pst.setString(4, pd.getLastname());                    
       pst.setString(5,pd.getNic()); 
       pst.setDate(6, pd.getDob());
       pst.setInt(7, pd.getConnum());
       pst.setString(8,pd.getAddress());
       pst.setString(9,Character.toString(pd.getGender()));
       pst.setString(10, pd.getIntake());
       pst.setDate(11,getCurrentDate());
       pst.setString(12,pd.getQualType());
       pst.setString(13, pd.getInstitute());
       pst.setString(14,pd.getYear_completed());
       
       pst.executeUpdate();
       
       String query6="SELECT std_id FROM postgraduate ORDER BY std_id DESC LIMIT 1";
       pst1=con.prepareStatement(query6);
       rs=pst1.executeQuery();
       rs.next (); 
       JOptionPane.showMessageDialog(null, "Inserted successfully! Student ID is "+rs.getString(1));
        
     }catch(Exception e){
        System.out.println(e);
        
    }
    }
}
