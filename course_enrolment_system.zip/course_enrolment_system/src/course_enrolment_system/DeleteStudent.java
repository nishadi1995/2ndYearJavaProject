package course_enrolment_system;

//import com.sun.corba.se.impl.protocol.giopmsgheaders.MessageBase;
import javax.swing.JOptionPane;

public class DeleteStudent extends javax.swing.JFrame {

    StudentsDBOperations dbops = new StudentsDBOperations();

    public DeleteStudent() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtStdID = new javax.swing.JTextField();
        btnDeleteUn = new javax.swing.JButton();
        btnDeletePo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("NSBM University");

        jPanel2.setBackground(new java.awt.Color(108, 108, 154));

        jLabel1.setText("Enter Student ID");

        btnDeleteUn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnDeleteUn.setText("DELETE UNDERGRADUATE");
        btnDeleteUn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteUnActionPerformed(evt);
            }
        });

        btnDeletePo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnDeletePo.setText("DELETE POSTGRADUATE");
        btnDeletePo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletePoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtStdID, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnDeletePo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDeleteUn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtStdID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(btnDeleteUn)
                .addGap(18, 18, 18)
                .addComponent(btnDeletePo)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(102, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(99, 99, 99))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(132, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteUnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteUnActionPerformed
        if ("".equals(txtStdID.getText())) {
            JOptionPane.showMessageDialog(null, "Please enter an index number");
        } else {
            int y = JOptionPane.showConfirmDialog(null, "Do you realy want to delete?", "delete student", JOptionPane.YES_NO_OPTION);

            if (y == 0) {
                int x = dbops.deleteundergraduate(txtStdID.getText());
                switch (x) {
                    case 0:
                        JOptionPane.showMessageDialog(null, "Student ID is not found");
                        txtStdID.setText("");
                        break;
                    case 1:
                        JOptionPane.showMessageDialog(null, "Successfully deleted!!");
                        dispose();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Ops..Error while deleting");
                        break;
                }
            } else {
                dispose();                 //Releases all of the native screen resources used by this Window, its subcomponents, and all of its owned children.
            }
        }

    }//GEN-LAST:event_btnDeleteUnActionPerformed

    private void btnDeletePoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletePoActionPerformed
        if ("".equals(txtStdID.getText())) {
            JOptionPane.showMessageDialog(null, "Please enter an index number");
        } else {
            int y = JOptionPane.showConfirmDialog(null, "Do you realy want to delete?", "delete student", JOptionPane.YES_NO_OPTION);

            if (y == 0) {
                int x = dbops.deletepostgraduate(txtStdID.getText());
                switch (x) {
                    case 0:
                        JOptionPane.showMessageDialog(null, "Student ID is not found");
                        txtStdID.setText("");
                        break;
                    case 1:
                        JOptionPane.showMessageDialog(null, "Successfully deleted!!");
                        dispose();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Ops..Error while deleting");
                        break;
                }
            } else {
                dispose();                 //Releases all of the native screen resources used by this Window, its subcomponents, and all of its owned children.
            }
        }
    }//GEN-LAST:event_btnDeletePoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeleteStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeleteStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeleteStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeleteStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeleteStudent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeletePo;
    private javax.swing.JButton btnDeleteUn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txtStdID;
    // End of variables declaration//GEN-END:variables
}
