
package course_enrolment_system;


public class LecturerInstructorDetails {

    private int staff_id;
    private String name;
    private String address;
    private String email;
    private int connum;
    private String room;
    private int i;
    
    public int getStaff_id() {
        return staff_id;
    }

    
    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    
    public String getAddress() {
        return address;
    }

    
    public void setAddress(String address) {
        this.address = address;
    }

    
    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }

    
    public int getConnum() {
        return connum;
    }

    
    public void setConnum(int connum) {
        this.connum = connum;
    }

    
    public String getRoom() {
        return room;
    }

    
    public void setRoom(String room) {
        this.room = room;
    }

    
    public int getI() {
        return i;
    }

    
    public void setI(int i) {
        this.i = i;
    }
     
    
    
}
