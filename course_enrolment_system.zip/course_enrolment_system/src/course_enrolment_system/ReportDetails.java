package course_enrolment_system;

/**
 *
 * @author NISHADI
 */
public class ReportDetails {

    private int std_id;
    private String subcode;
    private String ass1;
    private String ass2;
    private String ass3;
    private String exammarks;
    private char grade;
    private String semester;
    private String subname;
    
    public int getStd_id() {
        return std_id;
    }

    
    public void setStd_id(int std_id) {
        this.std_id = std_id;
    }

    
    public String getSubcode() {
        return subcode;
    }

    
    public void setSubcode(String subcode) {
        this.subcode = subcode;
    }

    
    public String getAss1() {
        return ass1;
    }

    
    public void setAss1(String ass1) {
        this.ass1 = ass1;
    }

    
    public String getAss2() {
        return ass2;
    }

    
    public void setAss2(String ass2) {
        this.ass2 = ass2;
    }

    
    public String getAss3() {
        return ass3;
    }

    
    public void setAss3(String ass3) {
        this.ass3 = ass3;
    }

    
    public String getExammarks() {
        return exammarks;
    }

    
    public void setExammarks(String exammarks) {
        this.exammarks = exammarks;
    }

    
    public char getGrade() {
        return grade;
    }

    
    public void setGrade(char grade) {
        this.grade = grade;
    }
    
    public String getSemester() {
        return semester;
    }

    
    public void setSemester(String semester) {
        this.semester = semester;
    }
    
    public String getSubname() {
        return subname;
    }

   
    public void setSubname(String subname) {
        this.subname = subname;
    }



}
