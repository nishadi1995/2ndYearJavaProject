package course_enrolment_system;


import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class StudentsDBOperations extends DBconnect {


    void checkvalidation(String logusername, String logpassword) {
        try {
            connection();
            String query1 = "SELECT * FROM login WHERE username= ?";        //sql query to run

            pst = con.prepareStatement(query1);                             //A SQL statement with or without IN parameters can be pre-compiled and stored in a PreparedStatement object.This object can then be used to efficiently execute this statement multiple times.
            pst.setString(1, logusername);                                 //sets the parameter to a string.Driver then converts it to a SQL VARCHAR when it sends to the DB 
            rs = pst.executeQuery();                                        // execute the sql query and returns the object containing the data produced by the query
            boolean b = rs.next();                                          //moves the cursor one row forword from the current position.return true if the current row is valid

            if (b == false) {
                JOptionPane.showMessageDialog(null, "Error! Entered username doesn't exsist");
            } else {
                if (logpassword.equals(rs.getString(2))) {                      //retrives the value in 2nd colomn in resultset object
                    SecondWindow sw = new SecondWindow();
                    sw.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Password is incorrect");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public static java.sql.Date getCurrentDate() {
        java.util.Date today = new java.util.Date();              //return current date as sql.date
        return new java.sql.Date(today.getTime());
    }

    void addUndergraduate(UndergratDetails ud) {
        try {
            connection();
            String query2 = "SELECT course_id FROM courses WHERE course_name=?";
            pst1 = con.prepareStatement(query2);
            pst1.setString(1, ud.getCoursename());

            rs1 = pst1.executeQuery();
            rs1.next();

            String query3 = "INSERT INTO undergraduate VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = con.prepareStatement(query3);

            pst.setInt(1, ud.getStd_id());                            //add values to sql query
            pst.setString(2, ud.getFirstname());                      //add values to sql query
            pst.setString(3, ud.getMidname());                        //add values to sql query
            pst.setString(4, ud.getLastname());                       //add values to sql query
            pst.setString(5, ud.getNic());                             //add values to sql query
            pst.setDate(6, ud.getDob());
            pst.setInt(7, 0);
            pst.setString(8, ud.getAddress());
            pst.setInt(9, ud.getConnum());
            pst.setString(10, Character.toString(ud.getGender()));
            pst.setString(11, ud.getIntake());
            pst.setDate(12, getCurrentDate());
            pst.setString(13, ud.getAlresults());
            pst.setInt(14, ud.getDrank());
            pst.setInt(15, ud.getIrank());
            pst.setDouble(16, ud.getZscore());
            pst.setString(17, rs1.getString(1));

            pst.executeUpdate();                                     //execute the sql query and add values to db table

            String query5 = "SELECT std_id FROM undergraduate ORDER BY std_id DESC LIMIT 1";
            pst1 = con.prepareStatement(query5);
            rs = pst1.executeQuery();
            rs.next();
            JOptionPane.showMessageDialog(null, "Inserted successfully! Student ID is " + rs.getString(1));
        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Error,when inserting..");
        }

    }

    void addPostgraduate(PostgratDetails pd) {

        try {
            connection();

            String query6 = "SELECT course_id FROM courses WHERE course_name=?";
            pst1 = con.prepareStatement(query6);
            pst1.setString(1, pd.getCoursename());
            rs1 = pst1.executeQuery();
            rs1.next();

            String query7 = "INSERT INTO postgraduate VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = con.prepareStatement(query7);

            pst.setInt(1, pd.getStd_id());
            pst.setString(2, pd.getFirstname());
            pst.setString(3, pd.getMidname());
            pst.setString(4, pd.getLastname());
            pst.setString(5, pd.getNic());
            pst.setDate(6, pd.getDob());
            pst.setInt(7, 0);
            pst.setInt(8, pd.getConnum());
            pst.setString(9, pd.getAddress());
            pst.setString(10, Character.toString(pd.getGender()));
            pst.setString(11, pd.getIntake());
            pst.setDate(12, getCurrentDate());
            pst.setString(13, pd.getQualType());
            pst.setString(14, pd.getInstitute());
            pst.setString(15, pd.getYear_completed());
            pst.setString(16, rs1.getString(1));                             //retrieves the value of the designated column in the current row of this ResultSet object

            pst.executeUpdate();

            String query8 = "SELECT std_id FROM postgraduate ORDER BY std_id DESC LIMIT 1";
            pst1 = con.prepareStatement(query8);
            rs = pst1.executeQuery();
            rs.next();
            JOptionPane.showMessageDialog(null, "Inserted successfully! Student ID is " + rs.getString(1));

        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Error,when inserting..");
        }
    }

    int deleteundergraduate(String stdid) {
        try {
            connection();
            String query9 = "DELETE FROM undergraduate WHERE std_id=?";
            pst = con.prepareStatement(query9);
            pst.setInt(1, Integer.parseInt(stdid));
            int x = pst.executeUpdate();                       //returns either the row count for SQL Data Manipulation Language (DML) statements or 0 for SQL statements that return nothing
            return x;                                          //returns one if successfully deleted.

        } catch (Exception e) {
            System.out.println(e);
            return 2;
        }
    }

    int deletepostgraduate(String stdid) {
        try {
            connection();
            String query10 = "DELETE FROM postgraduate WHERE std_id=" + Integer.parseInt(stdid);
            pst = con.prepareStatement(query10);
            int x = pst.executeUpdate();
            return x;

        } catch (Exception e) {
            System.out.println(e);
            return 2;
        }
    }

    ResultSet viewStudent(String stdid)  {
        try {
            connection();
            String query11 = "SELECT first_name,middle_name,last_name,nic,dob,connum,address,gender,intake,en_date,course_id FROM undergraduate WHERE std_id = ?";
            pst = con.prepareStatement(query11,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            pst.setInt(1, Integer.parseInt(stdid));
            rs = pst.executeQuery();
            
            String query12 = "SELECT first_name,middle_name,last_name,nic,dob,connum,address,gender,intake,en_date,course_id FROM postgraduate WHERE std_id = ?";
            pst = con.prepareStatement(query12);
            pst.setInt(1, Integer.parseInt(stdid));
            rs1 = pst.executeQuery();
            
        if (rs.next()) {

           /* String query13= "SELECT course_name FROM courses WHERE course_id = ?"  ;
            pst = con.prepareStatement(query13);
            pst.setString(1, rs.getString(11));
            rs2 = pst.executeQuery();
            rs2.next();
            rs.updateString(11,rs2.getString(1));  */                              //Updates the designated column with a String value
            return rs;
        } else if (rs1.next()) {
            return rs1;
        } 
        
        } catch (Exception e) {
            System.out.println(e);
        }
        return rs;
    }

}
