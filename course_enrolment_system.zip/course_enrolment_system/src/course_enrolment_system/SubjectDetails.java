
package course_enrolment_system;


public class SubjectDetails {

    
    private String subname;
    private String subcode;
    private int fees;
    private int credits;
    private String course;
    private String yrsem;
    private int i;
    
    public String getSubname() {
        return subname;
    }

   
    public void setSubname(String subname) {
        this.subname = subname;
    }

    public String getSubcode() {
        return subcode;
    }

    
    public void setSubcode(String subcode) {
        this.subcode = subcode;
    }

    
    public int getFees() {
        return fees;
    }

    
    public void setFees(int fees) {
        this.fees = fees;
    }

    
    public int getCredits() {
        return credits;
    }

    
    public void setCredits(int credits) {
        this.credits = credits;
    }

    
    public String getCourse() {
        return course;
    }

    
    public void setCourse(String course) {
        this.course = course;
    }

    
    public String getYrsem() {
        return yrsem;
    }

    
    public void setYrsem(String yrsem) {
        this.yrsem = yrsem;
    }
    
    public int getI() {
        return i;
    }

   
    public void setI(int i) {
        this.i = i;
    }
}
