
package course_enrolment_system;


public class SubjectDetails {
    
}
