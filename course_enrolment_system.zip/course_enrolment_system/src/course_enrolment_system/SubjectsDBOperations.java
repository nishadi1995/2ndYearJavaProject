
package course_enrolment_system;


public class SubjectsDBOperations extends DBconnect {
    
}
