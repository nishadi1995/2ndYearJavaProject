
package course_enrolment_system;

import java.sql.*;
import java.text.SimpleDateFormat;


public class UndergratDetails {

    private int std_id;
    private String firstname;
    private String midname;
    private String lastname;
    private String nic;
    private java.util.Calendar dob;
    private int connum;
    private String address;
    private char gender;
    private String intake;
    private String coursename;
    private String alresults;
    private int drank; private int irank;
    private double zscore;
    
    public int getConnum() {
        return connum;
    }

    
    public void setConnum(int connum) {
        this.connum = connum;
    }

    
    public String getAddress() {
        return address;
    }

    
    public void setAddress(String address) {
        this.address = address;
    }

    
    public char getGender() {
        return gender;
    }

    
    public void setGender(char gender) {
        this.gender = gender;
    }

    
    public String getIntake() {
        return intake;
    }

    
    public void setIntake(String intake) {
        this.intake = intake;
    }

   
    public String getCoursename() {
        return coursename;
    }

    
    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

   
    public int getDrank() {
        return drank;
    }

    
    public void setDrank(int drank) {
        this.drank = drank;
    }

    
    public int getIrank() {
        return irank;
    }

    
    public void setIrank(int irank) {
        this.irank = irank;
    }

    
    public double getZscore() {
        return zscore;
    }

    
    public void setZscore(double zscore) {
        this.zscore = zscore;
    }

    
    public int getStd_id() {
        return std_id;
    }

    
    public void setStd_id(int std_id) {
        this.std_id = std_id;
    }

   
    public String getFirstname() {
        return firstname;
    }

    
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    
    public String getMidname() {
        return midname;
    }

    
    public void setMidname(String midname) {
        this.midname = midname;
    }

    
    public String getLastname() {
        return lastname;
    }

    
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    
    public String getNic() {
        return nic;
    }

    
    public void setNic(String nic) {
        this.nic = nic;
    }

    
    public java.sql.Date getDob() {
        /*SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yy");
        java.sql.Date sqldate=null;
        try{
         java.util.Date date = sdf.parse(dob);
         sqldate= new java.sql.Date(date.getTime());
        }catch(Exception e){
           System.out.println("Date awla");
           System.out.println(e);
        }*/
       
        return new java.sql.Date(dob.getTime().getTime());
    }

    
    public void setDob(java.util.Calendar dob) {
        
        this.dob = dob;
    }

    
    public String getAlresults() {
        return alresults;
    }

    
    public void setAlresults(String sub1,String sub2,String sub3) {
        this.alresults=sub1+sub2+sub3;
    }
    
}
